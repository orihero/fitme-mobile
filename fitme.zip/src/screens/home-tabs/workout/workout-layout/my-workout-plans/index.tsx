import MyWorkoutPlans from "./view";

export default MyWorkoutPlans;
