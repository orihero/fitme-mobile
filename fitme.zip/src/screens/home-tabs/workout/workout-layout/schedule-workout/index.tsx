import ScheduleWorkout from "./view";

export default ScheduleWorkout;
