import MyExercises from "./view";

export default MyExercises;
