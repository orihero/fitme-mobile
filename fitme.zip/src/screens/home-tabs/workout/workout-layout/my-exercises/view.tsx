import { View, ScrollView, TouchableOpacity } from "react-native";
import { styles } from "./style";
import {
  Box,
  ButtonTabs,
  ButtonPrimary,
} from "../../../../../components/common";
import { Assets } from "../../../../../utils/requireAssets";
import { MyExercisesHooks } from "./hooks";
import { COLORS } from "../../../../../constants/COLORS";

const MyExercisesView = () => {
  const {
    isFavorite,
    setIsFavorite,
    activeCategory,
    setActiveCategory,
    activeSubCategory,
    setActiveSubCategory,
    exerciseCategories,
    language,
    exercises,
    onRemove,
    loading,
    show,
    setShow,
    select,
    onSelect,
    onAdd,
    loadingSelect,
    onExercisePrice,
  } = MyExercisesHooks();

  return (
    <View style={styles.container}>
      <ButtonTabs
        primary
        active={isFavorite}
        setActive={setIsFavorite}
        titles={["Выбранные", "Выбрать из общей базы"]}
        containerStyle={styles.favoriteBtnCont}
        scroll={false}
      />

      <ButtonTabs
        secondary
        active={activeCategory}
        setActive={setActiveCategory}
        titles={[...exerciseCategories.map((a) => a.name[language])]}
        containerStyle={styles.categoryBtnCont}
      />

      <ButtonTabs
        active={activeSubCategory}
        setActive={setActiveSubCategory}
        titles={
          !!exerciseCategories && exerciseCategories.length > 0
            ? [
                ...exerciseCategories[activeCategory].children.map(
                  (a) => a.name[language]
                ),
              ]
            : []
        }
        containerStyle={styles.subCategoryBtnCont}
      />

      <ScrollView showsVerticalScrollIndicator={false}>
        {exercises.map((e, i) => (
          <TouchableOpacity
            key={e._id}
            activeOpacity={0.6}
            style={{ marginTop: 10 }}
            onPress={() => onExercisePrice(e)}
          >
            <Box
              dots={!!!isFavorite}
              dotsLoading={!!!isFavorite && loading && loading[i]}
              show={!!!isFavorite && show && show[i]}
              setShow={() =>
                !!!isFavorite && setShow({ [i]: !(show && show[i]) })
              }
              onRemove={() => !!!isFavorite && onRemove(i)}
              canSelect={!!isFavorite}
              select={select.find((a) => a === e._id)}
              onSelect={() => onSelect(e._id)}
              title={e.title}
              cover={{ uri: e.image }}
              containerStyle={{ marginTop: 10 }}
            />
          </TouchableOpacity>
        ))}
      </ScrollView>

      {!!!isFavorite && <View style={{ marginBottom: 100 }} />}

      {!!isFavorite && (
        <View style={{ paddingBottom: 90 }}>
          <ButtonPrimary
            fill
            disabled={!!!select.length}
            loading={loadingSelect}
            loadingColor={COLORS.WHITE}
            onPress={onAdd}
            style={styles.button}
            text="Добавить в  “ Выбранные “"
            textStyle={styles.buttonText}
          />
        </View>
      )}
    </View>
  );
};

export default MyExercisesView;
