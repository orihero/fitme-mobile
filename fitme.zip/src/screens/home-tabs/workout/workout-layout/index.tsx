import WorkoutLayout from "./view";

export default WorkoutLayout;
