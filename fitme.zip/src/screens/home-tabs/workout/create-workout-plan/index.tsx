import CreateWorkoutPlan from "./view";

export default CreateWorkoutPlan;
