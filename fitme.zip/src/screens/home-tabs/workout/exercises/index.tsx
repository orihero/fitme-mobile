import WorkoutExercises from "./view";

export default WorkoutExercises;
