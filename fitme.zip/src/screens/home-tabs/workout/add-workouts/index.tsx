import AddWorkout from "./view";

export default AddWorkout;
