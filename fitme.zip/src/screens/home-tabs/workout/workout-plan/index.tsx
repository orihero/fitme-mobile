import WorkoutPlanView from "./view";

export default WorkoutPlanView;
