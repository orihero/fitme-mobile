import WorkoutExerciseView from "./view";

export default WorkoutExerciseView;
