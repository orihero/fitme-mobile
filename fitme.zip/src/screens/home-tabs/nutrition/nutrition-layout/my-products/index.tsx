import MyProducts from "./view";

export default MyProducts;
