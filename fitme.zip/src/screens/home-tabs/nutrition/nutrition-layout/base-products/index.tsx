import BaseProducts from "./view";

export default BaseProducts;
