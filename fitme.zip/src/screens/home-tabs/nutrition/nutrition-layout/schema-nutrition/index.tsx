import SchemaNutrition from "./view";

export default SchemaNutrition;
