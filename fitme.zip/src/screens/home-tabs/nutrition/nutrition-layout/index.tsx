import NutritionLayout from "./view";

export default NutritionLayout;
