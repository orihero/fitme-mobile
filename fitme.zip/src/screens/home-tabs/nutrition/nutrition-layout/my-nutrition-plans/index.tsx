import MyNutritionPlans from "./view";

export default MyNutritionPlans;
