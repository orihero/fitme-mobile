import CalcDailyNorm from "./view";

export default CalcDailyNorm;
