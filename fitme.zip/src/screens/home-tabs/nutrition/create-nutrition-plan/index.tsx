import CreateNutrition from "./view";

export default CreateNutrition;
