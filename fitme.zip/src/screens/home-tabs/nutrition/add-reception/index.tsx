import AddReception from "./view";

export default AddReception;
