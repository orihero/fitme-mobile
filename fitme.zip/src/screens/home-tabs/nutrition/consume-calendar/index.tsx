import ConsumeCalendar from "./view";

export default ConsumeCalendar;
