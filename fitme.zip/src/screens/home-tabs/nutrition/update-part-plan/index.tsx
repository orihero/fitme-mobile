import UpdatePartPlan from "./view";

export default UpdatePartPlan;
