import AddPartPlan from "./view";

export default AddPartPlan;
