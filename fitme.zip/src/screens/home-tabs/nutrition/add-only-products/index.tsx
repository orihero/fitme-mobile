import AddOnlyProducts from "./view";

export default AddOnlyProducts;
