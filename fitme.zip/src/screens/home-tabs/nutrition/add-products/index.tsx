import AddProducts from "./view";

export default AddProducts;
