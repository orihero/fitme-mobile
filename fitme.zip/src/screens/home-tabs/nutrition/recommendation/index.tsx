import Recommendation from "./view";

export default Recommendation;
