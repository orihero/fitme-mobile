import Measurements from "./view";

export default Measurements;
