import CreateDish from "./view";

export default CreateDish;
