import { useEffect, useState } from "react";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useNavigation } from "@react-navigation/native";
import { useRedux } from "../../../../store/hooks";
import {
  selectLanguage,
  selectUser,
  setUser,
} from "../../../../store/slices/appSlice";
import { NUTRITION } from "../../../../navigation/ROUTES";
import { NutritionStackParamList } from "..";
import EventEmitter from "../../../../utils/EventEmitter";
import { Dish, Product, Response } from "../../../../types";
import { getSumValues } from "../../../../utils/getSumValues";
import { PRODUCT_AMOUNT } from "../../../../constants/AMOUNT";
import { selectDishCategories } from "../../../../store/slices/categorySlice";
import { ApiService } from "../../../../services";

export type CreateDishScreenNavigationProp = NativeStackNavigationProp<
  NutritionStackParamList,
  NUTRITION.CREATE_DISH
>;

export const CreateDishHooks = () => {
  const navigation = useNavigation<CreateDishScreenNavigationProp>();
  const [language] = useRedux(selectLanguage);
  const [user, dispatch] = useRedux(selectUser);
  const [dishCategories] = useRedux(selectDishCategories);

  const [name, setName] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const [products, setProducts] = useState<Product[]>([]);
  const [amounts, setAmounts] = useState<number[]>([]);
  const [calories, setCalories] = useState(0);
  const [protein, setProtein] = useState(0);
  const [oil, setOil] = useState(0);
  const [carb, setCarb] = useState(0);
  const [loading, setLoading] = useState(false);
  const [show, setShow] = useState<any>({});
  const [modalValue, setModalValue] = useState("");

  useEffect(() => {
    let arr: number[] = [];

    for (let i = 0; i < products.length; i++) {
      arr.push(PRODUCT_AMOUNT);
    }

    setAmounts(arr);
  }, [products]);

  useEffect(() => {
    if (products.length) {
      setCalories(getSumValues(products, amounts, "calories"));
      setProtein(getSumValues(products, amounts, "protein"));
      setOil(getSumValues(products, amounts, "oil"));
      setCarb(getSumValues(products, amounts, "carb"));
    } else {
      setCalories(0);
      setProtein(0);
      setOil(0);
      setCarb(0);
    }
  }, [amounts]);

  const addProducts = (ps: Product[]) => setProducts(ps);

  useEffect(() => {
    EventEmitter.addListener("onAddProducts", addProducts);

    return () => {
      EventEmitter.removeListener("onAddProducts", addProducts);
    };
  }, []);

  const onSubmit = async () => {
    if (user) {
      setLoading(true);
      try {
        const res = await ApiService.post<Response<Dish>>("/dishes", {
          name,
          products: products.map((p) => p._id),
          amounts,
          category: dishCategories[activeIndex]._id,
          creator: user._id,
        });

        dispatch(
          setUser({
            ...user,
            dishes: [...user.dishes, res.data],
          })
        );

        setLoading(false);
        navigation.goBack();
      } catch (e) {
        console.log("e: ", e);
        setLoading(false);
      }
    }
  };

  const onShow = (index: number, value: string) => {
    setModalValue(value);
    setShow({ index });
  };

  const onRemove = () => {
    setProducts(products.slice(0, -1));
  };

  const onRemoveByIndex = (index: number) => {
    // console.log("products: ", JSON.stringify(products, null, 4));
    setProducts(products.filter((p, i) => i !== index));
  };

  const navigateAddProducts = () => {
    navigation.navigate(NUTRITION.ADD_ONLY_PRODUCTS, { products });
  };

  const onCancel = () => {
    setShow({});
    setModalValue("");
  };

  const onSaveAmount = () => {
    const arr = amounts.map((a, i) => {
      if (i === show.index) {
        a = Number(modalValue);
      }

      return a;
    });
    setAmounts(arr);
    setShow({});
    setModalValue("");
  };

  return {
    categories: dishCategories,
    show,
    loading,
    language,
    calories,
    protein,
    oil,
    carb,
    products,
    amounts,
    name,
    setName,
    activeIndex,
    setActiveIndex,
    modalValue,
    setModalValue,
    onSubmit,
    onShow,
    onCancel,
    onSaveAmount,
    onRemove,
    onRemoveByIndex,
    navigateAddProducts,
  };
};
