import WorkoutResults from "./view";

export default WorkoutResults;
