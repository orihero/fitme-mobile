import Welcome from "./view";

export default Welcome;
