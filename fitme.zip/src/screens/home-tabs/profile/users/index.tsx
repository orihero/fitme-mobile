import Users from "./view";

export default Users;
