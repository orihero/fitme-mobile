import MyTrainer from "./view";

export default MyTrainer;
