import { View, Text } from "react-native";
import { styles } from "./style";

const MyTrainerView = () => {
  return (
    <View style={styles.container}>
      <Text>MyTrainerView</Text>
    </View>
  );
};

export default MyTrainerView;
