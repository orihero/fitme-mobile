import Notifications from "./view";

export default Notifications;
