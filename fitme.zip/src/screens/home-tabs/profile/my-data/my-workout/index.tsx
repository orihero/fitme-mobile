import MyWorkout from "./view";

export default MyWorkout;
