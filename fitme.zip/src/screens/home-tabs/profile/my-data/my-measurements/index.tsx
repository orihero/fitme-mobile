import MyMeasurements from "./view";

export default MyMeasurements;
