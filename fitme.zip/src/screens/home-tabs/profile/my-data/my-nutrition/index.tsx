// import MyNutrition from "./view";
import MyNutrition from "./nview";

export default MyNutrition;
