import MyData from "./view";

export default MyData;
