import ProfileHome from "./view";

export default ProfileHome;
