import Exercise from "./view";

export default Exercise;
