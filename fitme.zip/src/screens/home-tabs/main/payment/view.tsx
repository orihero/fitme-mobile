import { View, Text } from "react-native";
import { styles } from "./style";

const PaymentView = () => {
  return (
    <View style={styles.container}>
      <Text>PaymentView</Text>
    </View>
  );
};

export default PaymentView;
