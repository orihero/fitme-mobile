import Payment from "./view";

export default Payment;
