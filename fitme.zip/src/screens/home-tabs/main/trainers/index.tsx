import Trainers from "./view";

export default Trainers;
