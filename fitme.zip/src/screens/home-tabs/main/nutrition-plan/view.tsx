import { View, Text } from "react-native";
import { styles } from "./style";

const NutritionPlanView = () => {
  return (
    <View style={styles.container}>
      <Text>NutritionPlanView</Text>
    </View>
  );
};

export default NutritionPlanView;
