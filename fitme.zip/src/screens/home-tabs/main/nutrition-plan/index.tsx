import NutritionPlan from "./view";

export default NutritionPlan;
