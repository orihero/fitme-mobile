import WorkoutPlan from "./view";

export default WorkoutPlan;
