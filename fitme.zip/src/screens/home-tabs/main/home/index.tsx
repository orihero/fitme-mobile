import MainHome from "./view";

export default MainHome;
