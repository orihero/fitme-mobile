import NutritionPlans from "./view";

export default NutritionPlans;
