import Trainer from "./view";

export default Trainer;
