import Exercises from "./view";

export default Exercises;
