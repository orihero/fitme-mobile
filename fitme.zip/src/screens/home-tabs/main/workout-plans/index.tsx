import WorkoutPlans from "./view";

export default WorkoutPlans;
