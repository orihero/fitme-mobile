import CreateExerciseScreen from "./view";

export default CreateExerciseScreen