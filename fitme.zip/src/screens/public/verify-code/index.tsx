import VerifyCode from "./view";

export default VerifyCode;
