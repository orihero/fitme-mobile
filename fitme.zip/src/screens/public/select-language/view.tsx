import { View, Text } from "react-native";
import { styles } from "./style";

const SelectLanguageView = () => {
  return (
    <View style={styles.container}>
      <Text>SelectLanguageView</Text>
    </View>
  );
};

export default SelectLanguageView;
