import SelectLanguage from "./view";

export default SelectLanguage;
