import SignUp from "./view";

export default SignUp;
