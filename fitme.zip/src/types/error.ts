export type ErrorType = {
  code?: number;
  error?: boolean;
  message?: string;
};
