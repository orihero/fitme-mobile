export const PRODUCT_AMOUNT = 100;
