// const serverUrl = "http://localhost:4000";
// const serverUrl = "http://192.168.31.138:4000";
// const serverUrl = "https://fitme-api-yng7n.ondigitalocean.app";
// const serverUrl = "http://127.0.0.1:5001";
// const serverUrl = "http://10.0.2.2:5000"; //http://185.196.213.144:5000/
// const serverUrl = "http://185.196.213.144:5000";
const serverUrl = "http://185.196.213.144:5000"; // AHOST



export const Env = {
  ApiUrl: `${serverUrl}/api`,
  AssetsUrl: serverUrl,
};
